package br.com.diego.notafiscal;

import java.math.BigDecimal;

public interface Imposto {
	BigDecimal valorImposto();
}
