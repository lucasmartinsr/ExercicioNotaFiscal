package br.com.diego.notafiscal;

import java.math.BigDecimal;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class NotaFiscalController {
	@Autowired
	private NotaFiscalRepository rp;

	private String notasFiscais = "notasfiscais";
	private String lstNotasFiscais = "listanotasfiscais";

	public BigDecimal valorImposto() {
		return BigDecimal.valueOf(0.1);
	}

	@GetMapping("/")
	public String index() {
		return "index";
	}

	@GetMapping("/listanotasfiscais")
	public String listaNotasFiscais(Model model) {
		Iterable<NotaFiscal> nf = rp.findAll();

		model.addAttribute(notasFiscais, nf);
		return lstNotasFiscais;
	}

	@PostMapping("/salvar")
	public String salvar(@RequestParam("nome") String nome, @RequestParam("valor") Double valor,
			@RequestParam("imposto") String imposto, Model model) {
		Imposto impostoSelecionado;

		
		if (imposto.toUpperCase().trim().compareTo("ICMS") == 0) {
			impostoSelecionado = new ICMS();
		} else {
			impostoSelecionado = new ISS();
		}

		NotaFiscal nf = new NotaFiscal(nome, impostoSelecionado.valorImposto().doubleValue(), valor);
		rp.save(nf);
		Iterable<NotaFiscal> nfList = rp.findAll();
		model.addAttribute(notasFiscais, nfList);
		return lstNotasFiscais;
	}

	@DeleteMapping("/delete")
	public String delete(@RequestParam("id") Integer id, Model model) {
		Optional<NotaFiscal> notaFiscal = rp.findById(id.longValue());

		if (notaFiscal.isPresent()) {
			rp.delete(notaFiscal.get());
		}

		Iterable<NotaFiscal> nfList = rp.findAll();
		model.addAttribute(notasFiscais, nfList);

		return lstNotasFiscais;
	}
}