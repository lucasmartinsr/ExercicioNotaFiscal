package br.com.diego.notafiscal;

import org.springframework.data.repository.CrudRepository;

public interface NotaFiscalRepository extends CrudRepository<NotaFiscal, Long> {
}